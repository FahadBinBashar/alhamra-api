<?php

namespace App\Http\Controllers;

use App\Models\Agent;
use App\Models\Employee;
use App\Models\Product;
use App\Models\ProductEmiPlan;
use App\Models\SalesOrder;
use App\Models\StockMovement;
use App\Models\Service;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class SalesOrderController extends Controller
{
    public function index(Request $request)
    {
        $this->ensureSalesEntryPermission($request->user());

        $orders = SalesOrder::with([
            'items.itemable',
            'agent.user',
            'branch',
            'customer',
            'employee.user',
            'sourceMe.user',
            'introducer',
            'rankDefinition',
        ])
            ->when($request->query('sales_type'), function ($query, $salesType) {
                if (in_array($salesType, SalesOrder::SALES_TYPES, true)) {
                    $query->where('sales_type', $salesType);
                }
            })
            ->orderByDesc('id')
            ->paginate((int) $request->query('per_page', 15));

        return response()->json($orders);
    }

    public function store(Request $request)
    {
        $user = $request->user();
        $this->ensureSalesEntryPermission($user);

        $data = $request->validate([
            'customer_id' => ['required', 'integer', 'exists:users,id'],
            'sales_type' => ['required', 'string', Rule::in(SalesOrder::SALES_TYPES)],
            'branch_id' => ['prohibited'],
            'agent_id' => ['prohibited'],
            'source_me_id' => ['prohibited'],
            'rank' => ['sometimes', 'string', Rule::exists('ranks', 'code')],
            'introducer_id' => ['nullable', 'integer', 'different:customer_id', 'exists:users,id'],
            'down_payment' => [
                Rule::requiredIf(fn () => $request->input('sales_type') !== SalesOrder::TYPE_SERVICE),
                'nullable',
                'numeric',
                'min:0',
            ],
            'installment_tenure_months' => ['nullable', 'integer', 'min:1'],
            'total' => ['required', 'numeric', 'min:0'],
            'items' => ['sometimes', 'array', Rule::requiredIf(fn () => $request->input('sales_type') === SalesOrder::TYPE_SERVICE)],
            'items.*.item_type' => ['required_with:items', 'string', 'in:product,service'],
            'items.*.item_id' => ['required_with:items', 'integer'],
            'items.*.qty' => ['required_with:items', 'integer', 'min:1'],
            'items.*.unit_price' => ['nullable', 'numeric', 'min:0'],
        ]);

        $data = $this->applyEntryRoleConstraints($user, $data);
        $data = $this->applyCustomerContextDefaults($data);
        $data = $this->applySourceContext($user, $data, true);
        $data['created_by'] = $this->resolveCreatedByFlag($user);

        $preparedItems = null;
        if (! empty($data['items'])) {
            $preparedItems = $this->prepareOrderItems($data['items']);
            $data['items'] = $preparedItems['items'];
            if ($preparedItems['total'] > 0) {
                $data['total'] = $preparedItems['total'];
            }

            if ($data['sales_type'] === SalesOrder::TYPE_SERVICE) {
                foreach ($preparedItems['items'] as $index => $item) {
                    if ($item['itemable_type'] !== Service::class) {
                        throw ValidationException::withMessages([
                            "items.$index.item_type" => 'Service sales orders may only contain services.',
                        ]);
                    }
                }
            }
        }

        if ($data['sales_type'] === SalesOrder::TYPE_SERVICE) {
            $data['down_payment'] = null;
        }

        $this->ensureEmiPlanForTenure($data['installment_tenure_months'] ?? null, $preparedItems['items'] ?? []);

        if (isset($data['down_payment']) && $data['down_payment'] > $data['total']) {
            throw ValidationException::withMessages([
                'down_payment' => 'The down payment may not be greater than the total amount.',
            ]);
        }

        $this->ensureAgentBelongsToBranch($data['agent_id'] ?? null, $data['branch_id'] ?? null);

        $order = DB::transaction(function () use ($data, $preparedItems) {
            $payload = Arr::only($data, [
                'customer_id',
                'employee_id',
                'source_me_id',
                'agent_id',
                'branch_id',
                'sales_type',
                'rank',
                'introducer_id',
                'down_payment',
                'installment_tenure_months',
                'total',
                'created_by',
            ]);
            $payload['status'] = SalesOrder::STATUS_ACTIVE;

            /** @var SalesOrder $order */
            $order = SalesOrder::create($payload);

            if ($preparedItems) {
                $order->items()->createMany($preparedItems['items']);
            }

            $order->load('items.itemable');
            $this->syncStockForSalesOrder($order);

            return $order;
        });

        return response()->json([
            'data' => $order->load([
                'items.itemable',
                'agent.user',
                'branch',
                'customer',
                'employee.user',
                'sourceMe.user',
                'introducer',
                'rankDefinition',
            ]),
        ], 201);
    }

    public function show(Request $request, SalesOrder $salesOrder)
    {
        $this->ensureSalesEntryPermission($request->user());

        return response()->json([
            'data' => $salesOrder->load([
                'items.itemable',
                'agent.user',
                'branch',
                'customer',
                'employee.user',
                'sourceMe.user',
                'introducer',
                'rankDefinition',
            ]),
        ]);
    }

    public function update(Request $request, SalesOrder $salesOrder)
    {
        $this->ensureSalesEntryPermission($request->user());

        $data = $request->validate([
            'customer_id' => ['sometimes', 'integer', 'exists:users,id'],
            'sales_type' => ['sometimes', 'string', Rule::in(SalesOrder::SALES_TYPES)],
            'branch_id' => ['prohibited'],
            'agent_id' => ['prohibited'],
            'source_me_id' => ['prohibited'],
            'rank' => ['sometimes', 'string', Rule::exists('ranks', 'code')],
            'introducer_id' => ['sometimes', 'nullable', 'integer', 'different:customer_id', 'exists:users,id'],
            'down_payment' => [
                'sometimes',
                'nullable',
                'numeric',
                'min:0',
            ],
            'installment_tenure_months' => ['sometimes', 'nullable', 'integer', 'min:1'],
            'total' => ['sometimes', 'numeric', 'min:0'],
            'status' => ['sometimes', 'string', Rule::in(SalesOrder::STATUSES)],
            'items' => ['sometimes', 'array'],
            'items.*.item_type' => ['required_with:items', 'string', 'in:product,service'],
            'items.*.item_id' => ['required_with:items', 'integer'],
            'items.*.qty' => ['required_with:items', 'integer', 'min:1'],
            'items.*.unit_price' => ['nullable', 'numeric', 'min:0'],
        ]);

        $data = $this->applyEntryRoleConstraints($request->user(), $data);
        $data = $this->applyCustomerContextDefaults($data, $salesOrder);

        $isSwitchingCustomer = array_key_exists('customer_id', $data)
            && (int) $data['customer_id'] !== (int) $salesOrder->customer_id;

        if (! array_key_exists('rank', $data) && ! $isSwitchingCustomer) {
            $data['rank'] = $salesOrder->rank;
        }

        $data = $this->applySourceContext($request->user(), $data, false, $salesOrder, $isSwitchingCustomer);

        $itemsProvided = array_key_exists('items', $data);
        $preparedItems = ['items' => []];

        if ($itemsProvided) {
            $preparedItems = $this->prepareOrderItems($data['items'] ?? []);
            $data['total'] = $preparedItems['total'];
            unset($data['items']);
        }

        $currentSalesType = $data['sales_type'] ?? $salesOrder->sales_type;

        if ($itemsProvided && $currentSalesType === SalesOrder::TYPE_SERVICE) {
            foreach ($preparedItems['items'] as $index => $item) {
                if ($item['itemable_type'] !== Service::class) {
                    throw ValidationException::withMessages([
                        "items.$index.item_type" => 'Service sales orders may only contain services.',
                    ]);
                }
            }
        }

        if ($currentSalesType === SalesOrder::TYPE_SERVICE) {
            $data['down_payment'] = null;
        }

        $itemsForTenureCheck = $itemsProvided ? ($preparedItems['items'] ?? []) : $this->resolveExistingOrderItems($salesOrder);
        $tenureForCheck = $data['installment_tenure_months'] ?? $salesOrder->installment_tenure_months;
        $this->ensureEmiPlanForTenure($tenureForCheck, $itemsForTenureCheck);

        $branchId = $data['branch_id'] ?? $salesOrder->branch_id;
        $agentId = $data['agent_id'] ?? $salesOrder->agent_id;
        $this->ensureAgentBelongsToBranch($agentId, $branchId);

        $total = $data['total'] ?? $salesOrder->total;
        $downPayment = $data['down_payment'] ?? $salesOrder->down_payment;

        if ($downPayment !== null && $downPayment > $total) {
            throw ValidationException::withMessages([
                'down_payment' => 'The down payment may not be greater than the total amount.',
            ]);
        }

        DB::transaction(function () use ($salesOrder, $data, $itemsProvided, $preparedItems) {
            if ($itemsProvided) {
                $this->revertStockMovementsForOrder($salesOrder);
            }

            $salesOrder->fill($data);
            $salesOrder->save();

            if ($itemsProvided) {
                $salesOrder->items()->delete();

                if (! empty($preparedItems['items'])) {
                    $salesOrder->items()->createMany($preparedItems['items']);
                }

                $salesOrder->load('items.itemable');
                $this->syncStockForSalesOrder($salesOrder);
            }
        });

        return response()->json([
            'data' => $salesOrder->fresh()->load([
                'items.itemable',
                'agent.user',
                'branch',
                'customer',
                'employee.user',
                'sourceMe.user',
                'introducer',
                'rankDefinition',
            ]),
        ]);
    }

    public function destroy(Request $request, SalesOrder $salesOrder)
    {
        $this->ensureSalesEntryPermission($request->user());

        DB::transaction(function () use ($salesOrder) {
            $this->revertStockMovementsForOrder($salesOrder);
            $salesOrder->delete();
        });

        return response()->noContent();
    }

    private function ensureSalesEntryPermission(?User $user): void
    {
        if (! $user || ! in_array($user->role, [
            User::ROLE_ADMIN,
            User::ROLE_BRANCH_ADMIN,
            User::ROLE_AGENT_ADMIN,
            User::ROLE_AGENT,
        ], true)) {
            abort(403, 'You are not authorised to manage sales entries.');
        }
    }

    private function resolveCreatedByFlag(?User $user): string
    {
        if (! $user) {
            return SalesOrder::CREATED_BY_SYSTEM;
        }

        return match ($user->role) {
            User::ROLE_ADMIN => SalesOrder::CREATED_BY_ADMIN,
            User::ROLE_BRANCH_ADMIN => SalesOrder::CREATED_BY_BRANCH_ADMIN,
            User::ROLE_AGENT, User::ROLE_AGENT_ADMIN => SalesOrder::CREATED_BY_AGENT,
            User::ROLE_CUSTOMER => SalesOrder::CREATED_BY_CUSTOMER,
            default => SalesOrder::CREATED_BY_SYSTEM,
        };
    }

    private function applySourceContext(
        ?User $user,
        array $data,
        bool $isNewOrder,
        ?SalesOrder $existing = null,
        bool $isSwitchingCustomer = false
    ): array {
        $sourceId = $data['source_me_id'] ?? null;
        $role = $user?->role;
        $requiresSource = $user && in_array($role, [User::ROLE_ADMIN, User::ROLE_BRANCH_ADMIN], true);

        if (! $sourceId) {
            if ($requiresSource && ($isNewOrder || $isSwitchingCustomer || ! $existing)) {
                throw ValidationException::withMessages([
                    'customer_id' => 'The selected customer does not have a marketing executive assigned.',
                ]);
            }

            if ($existing && ! $isSwitchingCustomer) {
                $data['employee_id'] = $existing->employee_id;
            } else {
                $data['employee_id'] = null;
            }

            return $data;
        }

        $sourceEmployee = Employee::find($sourceId);

        if (! $sourceEmployee) {
            throw ValidationException::withMessages([
                'customer_id' => 'The marketing executive associated with this customer could not be found.',
            ]);
        }

        return $this->resolveSourceContext($data, $sourceEmployee);
    }

    private function applyEntryRoleConstraints(?User $user, array $data): array
    {
        if (! $user) {
            return $data;
        }

        if (in_array($user->role, [User::ROLE_ADMIN, User::ROLE_BRANCH_ADMIN], true)) {
            $data['agent_id'] = null;
        }

        if (in_array($user->role, [User::ROLE_AGENT, User::ROLE_AGENT_ADMIN], true)) {
            $agentProfile = $user->agent;

            if (! $agentProfile) {
                throw ValidationException::withMessages([
                    'agent_id' => 'The authenticated agent profile is missing.',
                ]);
            }

            if (isset($data['agent_id']) && (int) $data['agent_id'] !== (int) $agentProfile->id) {
                throw ValidationException::withMessages([
                    'agent_id' => 'Agents may only manage orders for their own profile.',
                ]);
            }

            $data['agent_id'] = $agentProfile->id;

            if (! array_key_exists('branch_id', $data) || is_null($data['branch_id'])) {
                $data['branch_id'] = $agentProfile->branch_id;
            }
        }

        if (array_key_exists('agent_id', $data) && ! is_null($data['agent_id'])) {
            $data['agent_id'] = (int) $data['agent_id'];
        }

        if (array_key_exists('branch_id', $data) && ! is_null($data['branch_id'])) {
            $data['branch_id'] = (int) $data['branch_id'];
        }

        return $data;
    }

    private function applyCustomerContextDefaults(array $data, ?SalesOrder $existing = null): array
    {
        $customerId = $data['customer_id'] ?? $existing?->customer_id;

        if (! $customerId) {
            if ($existing) {
                $data['branch_id'] = $data['branch_id'] ?? $existing->branch_id;
                $data['agent_id'] = $data['agent_id'] ?? $existing->agent_id;
                $data['source_me_id'] = $data['source_me_id'] ?? $existing->source_me_id;
            }

            return $data;
        }

        $customer = User::find($customerId);

        if (! $customer) {
            return $data;
        }

        $isSwitchingCustomer = $existing
            && array_key_exists('customer_id', $data)
            && (int) $existing->customer_id !== (int) $customerId;

        if ($existing) {
            if ($isSwitchingCustomer) {
                $data['branch_id'] = $customer->added_by_branch_id;
                $data['agent_id'] = $customer->added_by_agent_id;
                $data['source_me_id'] = $customer->source_me_id;
            } else {
                $data['branch_id'] = $data['branch_id'] ?? $existing->branch_id ?? $customer->added_by_branch_id;
                $data['agent_id'] = $data['agent_id'] ?? $existing->agent_id ?? $customer->added_by_agent_id;
                $data['source_me_id'] = $data['source_me_id'] ?? $existing->source_me_id ?? $customer->source_me_id;
            }

            return $data;
        }

        $data['branch_id'] = $data['branch_id'] ?? $customer->added_by_branch_id;
        $data['agent_id'] = $data['agent_id'] ?? $customer->added_by_agent_id;
        $data['source_me_id'] = $data['source_me_id'] ?? $customer->source_me_id;

        return $data;
    }

    private function resolveExistingOrderItems(SalesOrder $order): array
    {
        $order->loadMissing('items');

        return $order->items
            ->map(fn ($item) => [
                'itemable_type' => $item->itemable_type,
                'itemable_id' => $item->itemable_id,
            ])
            ->all();
    }

    private function ensureEmiPlanForTenure(?int $tenureMonths, array $items): void
    {
        if (! $tenureMonths) {
            return;
        }

        $productIds = collect($items)
            ->filter(fn ($item) => ($item['itemable_type'] ?? null) === Product::class)
            ->map(fn ($item) => (int) $item['itemable_id'])
            ->unique()
            ->values();

        if ($productIds->isEmpty()) {
            return;
        }

        $missing = $productIds->reject(fn ($productId) => ProductEmiPlan::query()
            ->where('product_id', $productId)
            ->where('tenure_months', $tenureMonths)
            ->where('is_active', true)
            ->exists());

        if ($missing->isNotEmpty()) {
            throw ValidationException::withMessages([
                'installment_tenure_months' => 'The selected tenure does not have an EMI plan configured for this product.',
            ]);
        }
    }

    private function resolveSourceContext(array $data, Employee $employee): array
    {
        $data['source_me_id'] = $employee->id;
        $data['employee_id'] = $employee->id;

        if (! array_key_exists('branch_id', $data) || is_null($data['branch_id'])) {
            $data['branch_id'] = $employee->branch_id;
        }

        if (! array_key_exists('rank', $data) || is_null($data['rank'])) {
            $data['rank'] = $employee->rank;
        }

        $messages = [];

        if ($employee->branch_id && isset($data['branch_id']) && (int) $employee->branch_id !== (int) $data['branch_id']) {
            $messages['branch_id'] = 'The selected branch does not match the marketing executive profile.';
        }

        if ($employee->agent_id && isset($data['agent_id']) && (int) $employee->agent_id !== (int) $data['agent_id']) {
            $messages['agent_id'] = 'The selected agent does not match the marketing executive profile.';
        }

        if ($employee->rank && isset($data['rank']) && $employee->rank !== $data['rank']) {
            $messages['rank'] = 'The selected rank does not match the marketing executive profile.';
        }

        if ($messages) {
            throw ValidationException::withMessages($messages);
        }

        if (isset($data['branch_id'])) {
            $data['branch_id'] = (int) $data['branch_id'];
        }

        if (isset($data['agent_id']) && ! is_null($data['agent_id'])) {
            $data['agent_id'] = (int) $data['agent_id'];
        }

        return $data;
    }

    private function ensureAgentBelongsToBranch(?int $agentId, ?int $branchId): void
    {
        if (! $agentId || ! $branchId) {
            return;
        }

        $agent = Agent::find($agentId);

        if ($agent && $agent->branch_id && (int) $agent->branch_id !== (int) $branchId) {
            throw ValidationException::withMessages([
                'agent_id' => 'The selected agent does not belong to the specified branch.',
            ]);
        }
    }

    private function syncStockForSalesOrder(SalesOrder $order): void
    {
        $order->loadMissing('items.itemable');

        foreach ($order->items as $item) {
            $product = $item->itemable;

            if (! $product instanceof Product) {
                continue;
            }

            if (! $product->is_stock_managed || $product->product_type === 'land') {
                continue;
            }

            $qty = (float) $item->qty;

            if ($qty <= 0) {
                continue;
            }

            StockMovement::create([
                'product_id' => $product->id,
                'type' => StockMovement::TYPE_OUT,
                'qty' => $qty,
                'ref_type' => 'sales_order',
                'ref_id' => $order->id,
            ]);

            Product::query()->whereKey($product->id)->decrement('stock_qty', $qty);
        }
    }

    private function revertStockMovementsForOrder(SalesOrder $order): void
    {
        $movements = StockMovement::query()
            ->where('ref_type', 'sales_order')
            ->where('ref_id', $order->id)
            ->get();

        if ($movements->isEmpty()) {
            return;
        }

        foreach ($movements as $movement) {
            $qty = (float) $movement->qty;

            if ($movement->type === StockMovement::TYPE_OUT) {
                Product::query()->whereKey($movement->product_id)->increment('stock_qty', $qty);
            } elseif ($movement->type === StockMovement::TYPE_IN) {
                Product::query()->whereKey($movement->product_id)->decrement('stock_qty', $qty);
            }
        }

        StockMovement::query()
            ->where('ref_type', 'sales_order')
            ->where('ref_id', $order->id)
            ->delete();
    }

    private function prepareOrderItems(array $items): array
    {
        $resolved = [];
        $total = 0;

        foreach ($items as $index => $itemData) {
            $itemable = $this->resolveItemable($itemData['item_type'] ?? '', (int) ($itemData['item_id'] ?? 0), $index);
            $qty = (int) ($itemData['qty'] ?? 0);
            $unitPrice = array_key_exists('unit_price', $itemData)
                ? (float) $itemData['unit_price']
                : (float) ($itemable->price ?? 0);
            $lineTotal = round($qty * $unitPrice, 2);

            $resolved[] = [
                'itemable_type' => get_class($itemable),
                'itemable_id' => $itemable->id,
                'qty' => $qty,
                'unit_price' => $unitPrice,
                'line_total' => $lineTotal,
            ];

            $total += $lineTotal;
        }

        return [
            'items' => $resolved,
            'total' => round($total, 2),
        ];
    }

    private function resolveItemable(string $type, int $id, int $index)
    {
        $map = [
            'product' => Product::class,
            'service' => Service::class,
        ];

        if (! array_key_exists($type, $map)) {
            throw ValidationException::withMessages([
                "items.$index.item_type" => 'The selected item type is invalid.',
            ]);
        }

        $modelClass = $map[$type];
        $model = $modelClass::find($id);

        if (! $model) {
            throw ValidationException::withMessages([
                "items.$index.item_id" => 'The selected item is invalid.',
            ]);
        }

        return $model;
    }
}
