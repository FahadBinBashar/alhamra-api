<?php

namespace Tests\Feature;

use App\Models\Agent;
use App\Models\Branch;
use App\Models\Category;
use App\Models\Employee;
use App\Models\Rank;
use App\Models\Product;
use App\Models\SalesOrder;
use App\Models\StockMovement;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class SalesOrderTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->ensureRanks(Employee::RANKS);
    }

    public function test_admin_can_create_sales_order_with_implicit_context(): void
    {
        $branch = Branch::create([
            'name' => 'Dhaka Branch',
            'code' => 'DHK',
            'address' => 'Dhaka',
        ]);

        $admin = User::factory()->create([
            'role' => User::ROLE_ADMIN,
        ]);

        $agentUser = User::factory()->create([
            'role' => User::ROLE_AGENT,
        ]);

        $agent = Agent::create([
            'user_id' => $agentUser->id,
            'branch_id' => $branch->id,
            'agent_code' => Str::uuid()->toString(),
        ]);

        $marketingExecutiveUser = User::factory()->create([
            'role' => User::ROLE_EMPLOYEE,
        ]);

        $marketingExecutive = Employee::create([
            'user_id' => $marketingExecutiveUser->id,
            'branch_id' => $branch->id,
            'agent_id' => $agent->id,
            'rank' => Employee::RANK_ME,
        ]);

        $customer = User::factory()->create([
            'source_me_id' => $marketingExecutive->id,
            'added_by_branch_id' => $branch->id,
            'added_by_agent_id' => $agent->id,
        ]);

        $category = Category::create([
            'name' => 'Land',
            'type' => 'product',
        ]);

        $product = Product::create([
            'category_id' => $category->id,
            'name' => 'Premium Plot',
            'product_type' => 'land',
            'price' => 500000,
            'attributes' => [],
        ]);

        Sanctum::actingAs($admin);

        $response = $this->postJson('/api/v1/sales-orders', [
            'customer_id' => $customer->id,
            'sales_type' => SalesOrder::TYPE_LAND,
            'down_payment' => 50000,
            'total' => 500000,
            'items' => [
                [
                    'item_type' => 'product',
                    'item_id' => $product->id,
                    'qty' => 1,
                ],
            ],
        ]);

        $response->assertCreated();

        $response->assertJsonPath('data.branch_id', $branch->id);
        $response->assertJsonPath('data.agent_id', $agent->id);
        $response->assertJsonPath('data.rank', Employee::RANK_ME);
        $response->assertJsonPath('data.source_me_id', $marketingExecutive->id);
        $response->assertJsonPath('data.employee_id', $marketingExecutive->id);
        $response->assertJsonPath('data.created_by', SalesOrder::CREATED_BY_ADMIN);
        $response->assertJsonPath('data.sales_type', SalesOrder::TYPE_LAND);
        $response->assertJsonPath('data.items.0.itemable_id', $product->id);

        $this->assertDatabaseHas('sales_orders', [
            'customer_id' => $customer->id,
            'branch_id' => $branch->id,
            'agent_id' => $agent->id,
            'rank' => Employee::RANK_ME,
            'sales_type' => SalesOrder::TYPE_LAND,
            'source_me_id' => $marketingExecutive->id,
            'created_by' => SalesOrder::CREATED_BY_ADMIN,
        ]);
    }

    public function test_rank_employee_cannot_create_sales_order(): void
    {
        $branch = Branch::create([
            'name' => 'Chattogram Branch',
            'code' => 'CTG',
            'address' => 'Chattogram',
        ]);

        $rankUser = User::factory()->create([
            'role' => User::ROLE_EMPLOYEE,
        ]);

        $agent = Agent::create([
            'user_id' => $rankUser->id,
            'branch_id' => $branch->id,
            'agent_code' => Str::uuid()->toString(),
        ]);

        $marketingExecutive = Employee::create([
            'user_id' => $rankUser->id,
            'branch_id' => $branch->id,
            'agent_id' => $agent->id,
            'rank' => Employee::RANK_ME,
        ]);

        $customer = User::factory()->create();

        Sanctum::actingAs($rankUser);

        $response = $this->postJson('/api/v1/sales-orders', [
            'customer_id' => $customer->id,
            'sales_type' => SalesOrder::TYPE_SERVICE,
            'source_me_id' => $marketingExecutive->id,
            'down_payment' => 1000,
            'total' => 2000,
        ]);

        $response->assertForbidden();
        $this->assertDatabaseCount('sales_orders', 0);
    }

    public function test_agent_sales_order_does_not_require_marketing_executive(): void
    {
        $branch = Branch::create([
            'name' => 'Sylhet Branch',
            'code' => 'SYL',
            'address' => 'Sylhet',
        ]);

        $agentUser = User::factory()->create([
            'role' => User::ROLE_AGENT,
        ]);

        $agent = Agent::create([
            'user_id' => $agentUser->id,
            'branch_id' => $branch->id,
            'agent_code' => Str::uuid()->toString(),
        ]);

        $customer = User::factory()->create();

        Sanctum::actingAs($agentUser);

        $response = $this->postJson('/api/v1/sales-orders', [
            'customer_id' => $customer->id,
            'sales_type' => SalesOrder::TYPE_SERVICE,
            'down_payment' => 1000,
            'total' => 5000,
        ]);

        $response->assertCreated();

        $response->assertJsonPath('data.agent_id', $agent->id);
        $response->assertJsonPath('data.branch_id', $branch->id);
        $response->assertJsonPath('data.source_me_id', null);
        $response->assertJsonPath('data.employee_id', null);
        $response->assertJsonPath('data.created_by', SalesOrder::CREATED_BY_AGENT);

        $this->assertDatabaseHas('sales_orders', [
            'customer_id' => $customer->id,
            'agent_id' => $agent->id,
            'branch_id' => $branch->id,
            'source_me_id' => null,
            'employee_id' => null,
            'created_by' => SalesOrder::CREATED_BY_AGENT,
        ]);
    }

    public function test_agent_sales_order_inherits_customer_marketing_executive(): void
    {
        $branch = Branch::create([
            'name' => 'Rajshahi Branch',
            'code' => 'RAJ',
            'address' => 'Rajshahi',
        ]);

        $agentUser = User::factory()->create([
            'role' => User::ROLE_AGENT,
        ]);

        $agent = Agent::create([
            'user_id' => $agentUser->id,
            'branch_id' => $branch->id,
            'agent_code' => Str::uuid()->toString(),
        ]);

        $marketingExecutiveUser = User::factory()->create([
            'role' => User::ROLE_EMPLOYEE,
        ]);

        $marketingExecutive = Employee::create([
            'user_id' => $marketingExecutiveUser->id,
            'branch_id' => $branch->id,
            'agent_id' => $agent->id,
            'rank' => Employee::RANK_ME,
        ]);

        $customer = User::factory()->create([
            'source_me_id' => $marketingExecutive->id,
            'added_by_agent_id' => $agent->id,
            'added_by_branch_id' => $branch->id,
        ]);

        Sanctum::actingAs($agentUser);

        $response = $this->postJson('/api/v1/sales-orders', [
            'customer_id' => $customer->id,
            'sales_type' => SalesOrder::TYPE_ORDER,
            'down_payment' => 1000,
            'total' => 5000,
        ]);

        $response->assertCreated();
        $response->assertJsonPath('data.source_me_id', $marketingExecutive->id);
        $response->assertJsonPath('data.employee_id', $marketingExecutive->id);

        $this->assertDatabaseHas('sales_orders', [
            'customer_id' => $customer->id,
            'source_me_id' => $marketingExecutive->id,
            'employee_id' => $marketingExecutive->id,
        ]);
    }

    public function test_agent_cannot_assign_marketing_executive_to_sales_order(): void
    {
        $branch = Branch::create([
            'name' => 'Barishal Branch',
            'code' => 'BAR',
            'address' => 'Barishal',
        ]);

        $agentUser = User::factory()->create([
            'role' => User::ROLE_AGENT,
        ]);

        $agent = Agent::create([
            'user_id' => $agentUser->id,
            'branch_id' => $branch->id,
            'agent_code' => Str::uuid()->toString(),
        ]);

        $marketingExecutiveUser = User::factory()->create([
            'role' => User::ROLE_EMPLOYEE,
        ]);

        $marketingExecutive = Employee::create([
            'user_id' => $marketingExecutiveUser->id,
            'branch_id' => $branch->id,
            'agent_id' => $agent->id,
            'rank' => Employee::RANK_ME,
        ]);

        $customer = User::factory()->create();

        Sanctum::actingAs($agentUser);

        $response = $this->postJson('/api/v1/sales-orders', [
            'customer_id' => $customer->id,
            'sales_type' => SalesOrder::TYPE_ORDER,
            'source_me_id' => $marketingExecutive->id,
            'down_payment' => 2000,
            'total' => 10000,
        ]);

        $response->assertStatus(422);
        $response->assertJsonValidationErrors(['source_me_id']);

        $this->assertDatabaseCount('sales_orders', 0);
    }

    public function test_admin_sales_order_requires_marketing_executive(): void
    {
        $branch = Branch::create([
            'name' => 'Rangpur Branch',
            'code' => 'RNG',
            'address' => 'Rangpur',
        ]);

        $admin = User::factory()->create([
            'role' => User::ROLE_ADMIN,
        ]);

        $customer = User::factory()->create();

        Sanctum::actingAs($admin);

        $response = $this->postJson('/api/v1/sales-orders', [
            'customer_id' => $customer->id,
            'sales_type' => SalesOrder::TYPE_SHARE,
            'down_payment' => 1500,
            'total' => 3000,
        ]);

        $response->assertStatus(422);
        $response->assertJsonValidationErrors(['customer_id']);

        $this->assertDatabaseCount('sales_orders', 0);
    }

    protected function ensureRanks(array $codes): void
    {
        foreach ($codes as $index => $code) {
            Rank::firstOrCreate(
                ['code' => $code],
                ['name' => $code, 'sort_order' => $index + 1]
            );
        }
    }

    public function test_product_sales_adjust_stock_levels(): void
    {
        $branch = Branch::create([
            'name' => 'Khulna Branch',
            'code' => 'KHL',
            'address' => 'Khulna',
        ]);

        $admin = User::factory()->create([
            'role' => User::ROLE_ADMIN,
        ]);

        $agentUser = User::factory()->create([
            'role' => User::ROLE_AGENT,
        ]);

        $agent = Agent::create([
            'user_id' => $agentUser->id,
            'branch_id' => $branch->id,
            'agent_code' => Str::uuid()->toString(),
        ]);

        $marketingExecutiveUser = User::factory()->create([
            'role' => User::ROLE_EMPLOYEE,
        ]);

        $marketingExecutive = Employee::create([
            'user_id' => $marketingExecutiveUser->id,
            'branch_id' => $branch->id,
            'agent_id' => $agent->id,
            'rank' => Employee::RANK_ME,
        ]);

        $customer = User::factory()->create();

        $category = Category::create([
            'name' => 'Electronics',
            'type' => 'product',
        ]);

        $product = Product::create([
            'category_id' => $category->id,
            'name' => 'Smartphone',
            'product_type' => 'small',
            'price' => 1000,
            'stock_qty' => 5,
            'min_stock_alert' => 2,
            'is_stock_managed' => true,
            'attributes' => [],
        ]);

        Sanctum::actingAs($admin);

        $response = $this->postJson('/api/v1/sales-orders', [
            'customer_id' => $customer->id,
            'sales_type' => SalesOrder::TYPE_ORDER,
            'source_me_id' => $marketingExecutive->id,
            'down_payment' => 0,
            'total' => 1000,
            'items' => [
                [
                    'item_type' => 'product',
                    'item_id' => $product->id,
                    'qty' => 1,
                    'unit_price' => 1000,
                ],
            ],
        ]);

        $response->assertCreated();

        $orderId = $response->json('data.id');
        $product->refresh();

        $this->assertSame(4.0, (float) $product->stock_qty);

        $this->assertDatabaseHas('stock_movements', [
            'product_id' => $product->id,
            'type' => StockMovement::TYPE_OUT,
            'ref_type' => 'sales_order',
            'ref_id' => $orderId,
            'qty' => '1.00',
        ]);

        $updateResponse = $this->putJson("/api/v1/sales-orders/{$orderId}", [
            'items' => [
                [
                    'item_type' => 'product',
                    'item_id' => $product->id,
                    'qty' => 2,
                    'unit_price' => 1000,
                ],
            ],
        ]);

        $updateResponse->assertOk();

        $product->refresh();

        $this->assertSame(3.0, (float) $product->stock_qty);

        $this->assertDatabaseHas('stock_movements', [
            'product_id' => $product->id,
            'type' => StockMovement::TYPE_OUT,
            'ref_type' => 'sales_order',
            'ref_id' => $orderId,
            'qty' => '2.00',
        ]);

        $this->assertDatabaseCount('stock_movements', 1);

        $deleteResponse = $this->deleteJson("/api/v1/sales-orders/{$orderId}");
        $deleteResponse->assertNoContent();

        $product->refresh();

        $this->assertSame(5.0, (float) $product->stock_qty);
        $this->assertDatabaseCount('stock_movements', 0);
    }
}
